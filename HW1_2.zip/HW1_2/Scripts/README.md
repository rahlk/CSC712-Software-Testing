## Using getIssues.py

- Enter your username and password @ Line 12
- Enter the repo owner and the repo name @ Line 15

## Running the script:

+ Use the following script

``` bash
$ python getIssues.py > Reports.log
```