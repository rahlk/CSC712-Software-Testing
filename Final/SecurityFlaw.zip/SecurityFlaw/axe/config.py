from lib import *
import sys,base
sys.dont_write_bytecode = True

def settings():
  return Bag(
    str = Bag(white=r'(["\' \t\r\n]|#.*)',

a=1,
    b=2,
    c=Bag(d=[1,2,3,4],
          g=dict(aa=23,bb=23),
          e='f'))
