import sys
sys.dont_write_bytecode = True
from lib import *

if __name__ == '__main__': eval(cmd())
